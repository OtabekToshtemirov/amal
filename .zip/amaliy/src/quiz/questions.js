export const Questions=[
    {
        id:0,
        title : 'What is React?',
        variants: ['Library', 'Framework', "I don't Know"],
        correct:0
    },
    {
        id:1,
        title: 'What is Component?',
        variants: ['Function', 'Class', 'Both'],
        correct: 2
    },
    {
        id:2,
        title: 'What is JSX?',
        variants: ['JSX is a syntax extension to JavaScript', 'JSX is a preprocessor step that adds XML syntax to JavaScript', 'Both'],
        correct: 2
    },
    {
        id:3,
        title: 'What is the difference between state and props?',
        variants: ['State is internal and props are external to the component that defines it', 'State is external and props are internal to the component that defines it', 'Both'],
        correct: 0

    },
    {
        id:4,
        title: 'What is the difference between state and props?',
        variants: ['State is internal and props are external to the component that defines it', 'State is external and props are internal to the component that defines it', 'Both'],
        correct: 0

    },
    {
        id:5,
        title: 'What is the difference between state and props?',
        variants: ['State is internal and props are external to the component that defines it', 'State is external and props are internal to the component that defines it', 'Both'],
        correct: 0
    },
    {
        id:6,
        title: 'What is useState?',
        variants: ['useState is a Hook that lets you add React state to function components', 'useState is a Hook that lets you add React state to class components', 'Both'],
        correct: 0
    },
    {
        id:7,
        title: 'What is useEffect?',
        variants: ['useEffect is a Hook that lets you add React state to function components', 'useEffect is a Hook that lets you add React state to class components', 'Both'],
        correct: 0
    },
    {
        id:8,
        title: 'What is useRef?',
        variants: ['useRef is a Hook that lets you add React state to function components', 'useRef is a Hook that lets you add React state to class components', 'Both'],
        correct: 0
    },
    {
        id:9,
        title: 'What is useReducer?',
        variants: ['useReducer is a Hook that lets you add React state to function components', 'useReducer is a Hook that lets you add React state to class components', 'Both'],
        correct: 0
    }



]