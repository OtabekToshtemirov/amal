import React from 'react';
import Quiz from "./quiz/Quiz";

function App() {
    return (
        <div>
            <Quiz/>
        </div>
    );
}

export default App;