// write 3 data with  users id , name , job

const data = [
    {
        id: 1,
        name: "John",
        job: "Developer"

    },
    {
        id: 2,
        name: "Jane",
        job: "Designer"
    },
    {
        id: 3,
        name: "Jack",
        job: "Manager"

    }
];

export default data;
